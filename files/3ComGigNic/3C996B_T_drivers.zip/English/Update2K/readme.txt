                          3Com (R) Corporation
                    3Com NIC Driver Update Kit for the
	    3Com 10/100/1000 PCI-X Server Network Interface Card Family
                             Version 1.0

This document describes the procedures for using the 3Com NIC Driver 
Update Kit to upgrade your driver and diagnostic program to the version 
of the software that is included on the Etherlink Server CD version 1.0 for
the 3Com 10/100/1000 PCI-X Server Network Interface Card Family.  

The 3Com NIC Driver Update Kit makes it possible to update your network 
software without having to use the control panel.  It can also be used 
to update many systems on a network automatically by using NetWare login 
scripts or software version management system.


Requirements
============
1) The update program will run on Windows NT 4.0 and Windows 2000

2) At least one 3C996 EtherLink Server 10/100/1000 PCI-X Server Network Interface Card must be installed in the system. 

Procedures for Updating the Driver and Diagnostic Program
=========================================================
1) Click Start.

2) In the start menu, click Run...

3) On the Run window, click Browse...

4) Find and click on the program Update.exe that came with this readme file

5) In the Browse window, click OK.

6) In the Run window, click OK.

7) On the 3Com NIC Driver Update Kit Windows, click Update Network Software.

8) Click OK when the update program finishes updating the network software.

9) Reboot your computer. This step is not necessary for Windows 2000, unless
there are more NICs to be inserted into the system.


Installing the 3Com NIC Diagnostic Program in addition to updating the NIC drivers
==================================================================================
On top of updating the NIC driver the 3Com NIC Driver Update Kit can 
be used to install the 3Com NIC Diagnostic program.  By using the command 
line parameter /diag the diagnostic program will be installed while your 
NIC driver is updated.  If you have already updated your driver and decide
later to install the 3Com NIC Diagnostic program, you can run the update 
program again, with the /diag parameter.

		Update.exe /diag

Installing the 3Com NIC Diagnostic Program by itself (no driver updates)
========================================================================
The 3Com NIC Driver Update Kit can be used to install just the 3Com NIC 
Diagnostic program.  This can be achieved by using the command line 
parameter /diagonly. 

		Update.exe /diagonly

This will NOT update the NIC drivers installed on your machine

Removing the 3Com NIC Diagnostic Program
========================================================================
The 3Com NIC Driver Update Kit can be used to remove the 3Com NIC Diagnostic 
program.  This can be achieved by using the command line parameter /remove,
as in 

		Update.exe /remove

Invoking the Update program without any command line parameters, will also
remove the 3Com NIC Diagnostic program. In fact, this will also remove the diagnostic program if any, that had been installed by an older version of 
Etherdisk.

The 3Com NIC Driver Update Kit in Unattended Mode
=================================================
The 3Com NIC Driver Update Kit has two command line parameters that allow
it to be used for unattended upgrades or to be used in software management 
applications to push the upgrade to the end-stations.  

The first option, /unattended, suppresses all dialog boxes so no user 
interaction is needed to perform the upgrade.  
The second, /preload, should only be used if the Driver Update Kit is 
called during the installation of the Operating System, or OS, and delays 
the installation of the 3Com Diagnostic Communication Protocol until the 
OS has finished its installation. Since running the Driver Update Kit 
during the OS install requires special software from Microsoft, like the 
OPK, if you are unsure on whether to call the /preload parameter we suggest
you attempt the OS install without this parameter first and only if this 
does not work should you use the /preload parameter.

		Update.exe /unattended [/preload] [/diag]

; (%VER \english\diagnostics\update\readme.txt - v1.0.0)
