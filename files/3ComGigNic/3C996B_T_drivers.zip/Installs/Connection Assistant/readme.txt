3COM CONNECTION ASSISTANT MINIMUM REQUIREMENTS

Processor: 200 MHz or faster
Memory: Minimum of 32 Mb RAM recommended, 16 Mb required
Operating System: Windows 95 B, Windows 98, Windows Millennium, Windows NT, Windows 2000 
Video: Resolution of 800 x 600 or greater recommended
Browser: Netscape 4.06 + or Internet Explorer 4.0+
Network: TCP/IP Protocol
Other: Microsoft JVM 4.79.2339 or later

